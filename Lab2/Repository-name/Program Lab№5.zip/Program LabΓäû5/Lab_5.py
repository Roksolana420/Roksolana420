from num2word import word
print("Hello")
"""Asks for user integer number"""
num = input("Enter number: ")

"""Prints user number as text"""
print("Your number is: "+ word(num))